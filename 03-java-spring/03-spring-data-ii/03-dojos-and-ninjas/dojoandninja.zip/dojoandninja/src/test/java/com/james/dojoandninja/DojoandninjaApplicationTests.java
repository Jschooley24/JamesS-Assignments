package com.james.dojoandninja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojoandninjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
