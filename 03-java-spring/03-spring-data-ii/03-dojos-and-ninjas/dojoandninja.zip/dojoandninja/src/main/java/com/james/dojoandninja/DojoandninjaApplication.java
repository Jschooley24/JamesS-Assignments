package com.james.dojoandninja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DojoandninjaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DojoandninjaApplication.class, args);
	}

}
