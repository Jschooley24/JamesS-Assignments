public class PuzzleTest {
    Puzzle p = new Puzzle();
    ArrayList<integer> randomRolls = p.getTenRolls());
    System.out.println(randRolls);
    System.out.println(p.randomLetter());
    System.out.println(p.genPass());
    System.out.println(p.getNewPassword());
    


}
