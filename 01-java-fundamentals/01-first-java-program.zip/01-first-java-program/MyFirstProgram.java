public class MyFirstProgram {
    public static void main (String [] args) {
        System.out.println("My name is James.");
        System.out.println("I am 33 years old.");
        System.out.println("I live in Boise,ID.");
        System.out.println("My hometown is Las Vegas,NV.");
}

}